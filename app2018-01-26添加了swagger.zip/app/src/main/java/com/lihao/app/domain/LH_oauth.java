package com.lihao.app.domain;

import javax.servlet.http.HttpServletRequest;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 第三方使用的方法
 * @author lihao.fnst
 *
 */
@Data
@NoArgsConstructor
public class LH_oauth {
	
	private String client_key;
	private String client_secret;
	private String redirect_url;
	private String scope;
	private String state;
	private HttpServletRequest request;
	
//	固定的授权页面的url
	private static final String POWERURL = "http://localhost:8080/app/auth/authorize?";
	
	/**
	 * 初始化
	 * @param client_key 表示客户端的ID，必选项
	 * @param client_secret
	 * @param redirect_url 表示重定向URI，可选项
	 * @param request
	 */
	public void LH_oauth(String client_key,String client_secret,String redirect_url,HttpServletRequest request){
		this.client_key = client_key;
		this.client_secret = client_secret;
		this.redirect_url = redirect_url;
		this.request = request;
	}
	
	/**
	 * 获取授权登陆的url
	 * response_type：表示授权类型，必选项，此处的值固定为"code"
	 * client_id：表示客户端的ID，必选项
	 * redirect_uri：表示重定向URI，可选项
	 * scope：表示申请的权限范围，可选项
	 * state：表示客户端的当前状态，可以指定任意值，认证服务器会原封不动地返回这个值。
	 * @return
	 */
	private String getAuthorizeUrl(){
		String new_url = POWERURL;
		new_url=new_url+"response_type=code&client_id="+client_key+
				"&client_secret="+client_secret+"&redirect_url="+redirect_url;
		return new_url;
	}
	
}
