package com.lihao.app.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.web.servlet.ModelAndView;

import com.lihao.app.domain.TokenBody;
import com.lihao.app.domain.json.LiHaoJson;
import com.lihao.app.domain.json.LoginJson;
import com.lihao.app.domain.json.SoftJson;

/**
 * 用户服务
 * @author lihao.fnst
 *
 */
public interface AuthService {
//	用户注册
	Integer Regiseter(LiHaoJson lihao) throws Exception;
//  应用注册
	int AddSoft(SoftJson softJson);
//	输入用户，用户认证成功进入授权页面，确定是否授权
	Boolean GetPower(HttpServletRequest request, HttpServletResponse response);
//	确定授权，生成授权码，将授权码链接到
	void GetUserTrue(LoginJson loginJson,HttpServletRequest request, HttpServletResponse response);
//	查找根据应用id 应用名
	ModelAndView authorization(HttpServletRequest request,HttpServletResponse response,ModelAndView mav);
//	生成授权码并发送给第三方
	void CreateCode(HttpServletRequest request, HttpServletResponse response);
//	用授权码生成token
	TokenBody GetAccessToken(HttpServletRequest request, HttpServletResponse response);
//	根据refreshtoken来更新token
	ResponseEntity<?> refresh_Token(HttpServletRequest request,
			HttpServletResponse response);
	
}
