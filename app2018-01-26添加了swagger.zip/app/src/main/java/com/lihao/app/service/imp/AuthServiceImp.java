package com.lihao.app.service.imp;

import java.io.IOException;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.lihao.app.dao.AuthSoftMapper;
import com.lihao.app.dao.AuthUserMapper;
import com.lihao.app.dao.ServiceMapper;
import com.lihao.app.domain.TokenBody;
import com.lihao.app.domain.enums.ResultEnum;
import com.lihao.app.domain.json.LiHaoJson;
import com.lihao.app.domain.json.LoginJson;
import com.lihao.app.domain.json.ResultBody;
import com.lihao.app.domain.json.SoftJson;
import com.lihao.app.entity.LiHao;
import com.lihao.app.entity.LiHaoCode;
import com.lihao.app.entity.LiHaoSoft;
import com.lihao.app.service.AuthService;
import com.lihao.app.utils.CodeUtils;
import com.lihao.app.utils.JwtTokenUtil;

@Service
public class AuthServiceImp implements AuthService {

	private static final Logger logger = LoggerFactory
			.getLogger(AuthServiceImp.class);

	@Autowired
	private AuthUserMapper userMapper;
	@Autowired
	private AuthSoftMapper softMapper;
	@Autowired
	private ServiceMapper serviceMapper;

	private JwtTokenUtil jwtutil = new JwtTokenUtil();

	private TokenBody token = new TokenBody();

	/**
	 * 账户注册
	 */
	@Override
	public Integer Regiseter(LiHaoJson lihao) throws Exception {
		// TODO Auto-generated method stub
		// 密码加密存入数据库中
		String password = lihao.getPassword();
		String m5Passwd = CodeUtils.md5String(password);
		lihao.setLastPasswordResetDate(new Date());
		lihao.setPassword(m5Passwd);
		int flag = userMapper.insert(lihao);
		return flag;
	}

	/**
	 * 未完成： 没有重复判断 应用程序的key,secret的生成（自动生成不重复） 应用程序的用户名应该自动后台获取，不该由用户输入
	 */
	@Override
	public int AddSoft(SoftJson softJson) {
		// TODO Auto-generated method stub
		int flag = softMapper.insert(softJson);
		return flag;
	}

	/**
	 * 第三方验证
	 */
	@Override
	public Boolean GetPower(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		String client_id = null;
		String redirect_url = null;

		// 获取客户端传过来的应用id
		client_id = request.getParameter("client_id");
		redirect_url = request.getParameter("redirect_url");

		// 相当于用户进行第三方验证 缺少快速登陆（已验证）
		LiHaoSoft soft = softMapper.selectSoft(client_id);
		if (soft != null) {
			logger.info("\n param:" + client_id);
			request.setAttribute("client_id", client_id);
			request.setAttribute("redirect_url", redirect_url);
			request.setAttribute("authorization",
					"你即将授权的应用为：" + soft.getClient_name());
			return true;
		} else {
			logger.info("\n验证失败");
			return false;
		}
	}

	/**
	 * 用户账号验证 进入授权确认页面获得code
	 */
	@Override
	public void GetUserTrue(LoginJson loginJson, HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub

		// 密码进行md5加密之后进行数据库中密码比较
		String password = loginJson.getPassword();
		String m5Passwd = null;
		HttpSession session = request.getSession();

		try {
			m5Passwd = CodeUtils.md5String(password);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (m5Passwd != null) {
			loginJson.setPassword(m5Passwd);
		}

		LiHao lihao = new LiHao();
		lihao = userMapper.selectUser(loginJson);
		logger.info("\n 查看request" + request.getParameter("client_id"));
		// 判断用户验证是否成功
		try {
			if (lihao != null) {
				// 登陆成功（用户授权）生成授权码 authorize
				logger.info("\n成功登入" + lihao.getId());
				session.setAttribute("userid", lihao.getId());
				response.sendRedirect("/app/authorize?response_type=code&client_id="
						+ request.getParameter("client_id")
						+ "&redirect_url="
						+ request.getParameter("redirect_url"));

			} else {
				response.sendRedirect("/app/error");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 中转站
	 */
	@Override
	public ModelAndView authorization(HttpServletRequest request,
			HttpServletResponse response, ModelAndView mav) {
		// TODO Auto-generated method stub
		String client_id = request.getParameter("client_id");
		String client_name = softMapper.selectSoft(client_id).getClient_name();
		String redirect_url = request.getParameter("redirect_url");

		logger.info("\n client_name \n" + client_name);
		mav.addObject("client_id", client_id);
		mav.addObject("authorization", client_name);
		mav.addObject("redirect_url", redirect_url);
		mav.setViewName("authorize");
		return mav;
	}

	/**
	 * 生成code
	 */
	@Override
	public void CreateCode(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub

		String code = new String();
		LiHaoCode liHaoCode = new LiHaoCode();
		String client_id = request.getParameter("client_id");
		String redirect_url = request.getParameter("redirect_url");
		HttpSession session = request.getSession();
		Integer userid = (Integer) session.getAttribute("userid");

		logger.info("\n\n create code=" + code);
		LiHaoCode exists = serviceMapper.selectCode(client_id);
		// 判断是否已经有了授权码
		try {
			if (exists != null) {
				code = exists.getCode();
				String new_url = redirect_url + "?code=" + code;
				response.sendRedirect(new_url);
			} else {
				code = userid + client_id + redirect_url;
				// 对code进行md5加密
				code = CodeUtils.md5String(code);
				// 讲code存入数据库
				liHaoCode.setClient_id(client_id);
				liHaoCode.setUserid(userid);
				liHaoCode.setCode(code);

				int flag = serviceMapper.insertCode(liHaoCode);
				if (flag != 0) {
					String new_url = redirect_url + "?code=" + code;
					response.sendRedirect(new_url);
				} else {
					response.sendRedirect("/app/error");
				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			try {
				e.printStackTrace();
				response.sendRedirect("/app/error");
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

	/**
	 * 需要通过code来获取token
	 */
	@Override
	public TokenBody GetAccessToken(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub

		String code = request.getParameter("code");
		HttpSession session = request.getSession();
		Integer userid = (Integer) session.getAttribute("userid");
		String client_id = request.getParameter("client_id");
		String client_secret = request.getParameter("client_secret");

		logger.info("\nclient_id:" + client_id + "\n" + client_secret + "\n"
				+ userid + "\n" + code);

		// 在数据库中查找是否存在相应的值
		LiHaoCode detailCode = serviceMapper.selectHavetoken(code);
		String get_secret = softMapper.selectSoft(client_id).getClient_secret();

		try {
			// 验证第三方应用
			if (detailCode != null
					&& client_id.equals(detailCode.getClient_id())
					&& client_secret.equals(get_secret)) {
				// token的生成
				LiHao lihao = userMapper.selectId(userid);
				logger.info("\n=============>userid:" + userid);
				if (lihao != null) {
					String username = lihao.getUsername();
					logger.info("\n==========>code And username:\n" + code
							+ "\n" + username);
					String access_token = jwtutil.generateToken(
							lihao.getUsername(), client_id);
					String refresh_token = jwtutil.getRefreshToken(
							lihao.getUsername(), client_id);
					token.setAccess_token(access_token);
					token.setRefresh_token(refresh_token);
					token.setScope("basic");
					logger.info("\n\ntoken test===========>>>"
							+ token.toString());
					return token;
				} else {
					logger.info("\n没有找到该用户");
					response.sendRedirect("/app/error");
				}
			} else {
				response.sendRedirect("/app/error");
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public ResponseEntity<?> refresh_Token(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		String refresh_token = request.getParameter("refresh_token");
		String client_id = request.getParameter("client_id");
		TokenBody token = new TokenBody();
		// 验证第三方网站
		String token_clientId = jwtutil.getClient_idFromToken(refresh_token);
		if (client_id.equals(token_clientId)) {
			// 判断refresh_token是否过期
			Boolean flag = jwtutil.isTokenExpired(refresh_token);
			if (flag) {
				return ResponseEntity.ok(new ResultBody(ResultEnum.FALUE,
						"refresh_token过期"));
			} else {
				String username = jwtutil.getUsernameFromToken(refresh_token);
				String accessToken = jwtutil.generateToken(username, client_id);
				// refresh 没有过期，重新生成token和refreshtoken
				token.setAccess_token(accessToken);
				token.setRefresh_token(jwtutil.refreshToken(accessToken));
				return ResponseEntity.ok(new ResultBody(ResultEnum.SUCCESS, token));
			}
		} else {
			return ResponseEntity.ok(new ResultBody(ResultEnum.FALUE, "非法网站"));
		}
		
	}
}
