package com.lihao.app.dao;

import org.springframework.stereotype.Repository;

import com.lihao.app.entity.LiHaoCode;
/**
 * 针对权限操作
 * @author lihao.fnst
 *
 */
@Repository
public interface ServiceMapper {
//	将授权码存入数据库
	int insertCode(LiHaoCode code);
//	通过应用id查找授权码
	LiHaoCode selectCode(String client_id);
//	通过code来查找是否存在
	LiHaoCode selectHavetoken(String code);
}
