package com.lihao.app.domain.json;

import com.lihao.app.domain.enums.ResultEnum;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 返回值格式
 * @author lihao.fnst
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ResultBody {
	private String code,describe;
	private Object content;
	public ResultBody(ResultEnum resultEnum,Object object){
		this.code = resultEnum.getCode();
		this.describe = resultEnum.getDescribe();
		this.content = object;
	}
}
