package com.lihao.app.entity;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * tb_user实体类
 * 
 * @author lihao.fnst
 *
 */

@Data
public class LiHao implements Serializable {
	private Integer id;
	private String username;
	private String password;
	private String name;
	private Integer age;
	// 密码更新的日期
	private Date lastPasswordResetDate;
}
