package com.lihao.app.domain;

/**
 * 提供给客户端使用的类
 * 用于将用户引导向授权页面
 * @author lihao.fnst
 *
 */
public class LiHaoStore {
	
}
