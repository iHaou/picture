package com.lihao.app.dao;

import org.springframework.stereotype.Repository;

import com.lihao.app.domain.json.SoftJson;
import com.lihao.app.entity.LiHaoSoft;

/**
 * 针对tb_soft数据库操作
 * @author lihao.fnst
 *
 */
@Repository
public interface AuthSoftMapper {
//  用户注册应用
	int insert(SoftJson softJson);
// 删除应用
	int Delete(int id);
//	查找应用
	LiHaoSoft selectSoft(String client_id);
}
