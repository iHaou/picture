package com.lihao.app.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ClientController {
	private static final Logger logger = LoggerFactory.getLogger(ClientController.class);
	
	private static final String redirect_url = "www.baidu.com";
	private static final String access_token = "/app/getToken";
	private String client_id = "clientAppkey";
	private String client_secret = "client_secret";

	@RequestMapping("auth/change")
	public void GetCode(HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		String code = request.getParameter("code");

		String newUrl = access_token + "?client_id=" + client_id
				+ "&client_secret=" + client_secret + "&redirect_url="
				+ redirect_url + "&code=" + code;
		logger.info("\n newURL="+newUrl);
		response.sendRedirect(newUrl);
	}
}
