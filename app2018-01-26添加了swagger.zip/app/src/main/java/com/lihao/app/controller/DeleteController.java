package com.lihao.app.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lihao.app.domain.enums.ResultEnum;
import com.lihao.app.domain.json.ResultBody;
import com.lihao.app.service.DeleteService;

@Controller
@RequestMapping("/delete")
public class DeleteController {

	private static final Logger logger = LoggerFactory
			.getLogger(DeleteController.class);

	@Autowired
	private DeleteService delService;
	
	/**
	 * 删除应用
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/soft", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> DelSoft(int id) {
		logger.info("\n delete userid:" + id);
		int flag = delService.delSoft(id);
		if (flag != 0) {
			return ResponseEntity.ok(new ResultBody(ResultEnum.SUCCESS, id));
		} else {
			return ResponseEntity.ok(new ResultBody(ResultEnum.FALUE, id));
		}
	}

	/**
	 * 删除用户
	 * 
	 * @param id
	 *            用户的id
	 * @return
	 */
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> Delregister(int id) {
		logger.info("\n delete userid:" + id);
		int flag = delService.delUser(id);
		if (flag != 0) {
			return ResponseEntity.ok(new ResultBody(ResultEnum.SUCCESS, id));
		} else {
			return ResponseEntity.ok(new ResultBody(ResultEnum.FALUE, id));
		}
	}
}
