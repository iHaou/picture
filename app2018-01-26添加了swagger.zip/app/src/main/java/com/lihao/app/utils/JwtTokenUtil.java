package com.lihao.app.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import org.springframework.context.support.StaticApplicationContext;
import org.springframework.stereotype.Component;

import com.lihao.app.entity.LiHao;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 用来从token中解析信息数据
 */
@Component
public class JwtTokenUtil implements Serializable {

	private static final long serialVersionUID = -3301605591108950415L;

	private static final String CLAIM_KEY_USERNAME = "sub";
	private static final String CLAIM_KEY_CREATED = "created";
	private static final String CLAIM_KEY_CLIENTID = "iss";
	private static final String secret = "mySecret";
	private static final Long expiration = 604800L;
	// 一年
	private static final Long refresh_time = 31536000L;

	/**
	 * 从token中获取用户名
	 * 
	 * @param token
	 * @return
	 */
	public String getUsernameFromToken(String token) {
		String username;
		try {
			final Claims claims = getClaimsFromToken(token);
			username = claims.getSubject();
		} catch (Exception e) {
			username = null;
		}
		return username;
	}

	/**
	 * 从token中获取client_id
	 * @param token
	 * @return
	 */
	public String getClient_idFromToken(String token) {
		String client_id;
		try {
			final Claims claims = getClaimsFromToken(token);
			client_id = claims.getIssuer();
		} catch (Exception e) {
			// TODO: handle exception
			client_id = null;
		}
		return client_id;
	}

	/**
	 * 从token中获得创建token的时间
	 * 
	 * @param token
	 * @return
	 */
	public Date getCreatedDateFromToken(String token) {
		Date created;
		try {
			final Claims claims = getClaimsFromToken(token);
			created = new Date((Long) claims.get(CLAIM_KEY_CREATED));
		} catch (Exception e) {
			created = null;
		}
		return created;
	}

	/**
	 * 从token中获得过期时间（有效期）
	 * 
	 * @param token
	 * @return
	 */
	public Date getExpirationDateFromToken(String token) {
		Date expiration;
		try {
			final Claims claims = getClaimsFromToken(token);
			expiration = claims.getExpiration();
		} catch (Exception e) {
			expiration = null;
		}
		return expiration;
	}

	// 将token转换成claims
	private Claims getClaimsFromToken(String token) {
		Claims claims;
		try {
			claims = Jwts.parser().setSigningKey(secret).parseClaimsJws(token)
					.getBody();
		} catch (Exception e) {
			claims = null;
		}
		return claims;
	}

	/**
	 * 获得系统当前时间
	 * 
	 * @return
	 */
	private Date generateExpirationDate() {
		return new Date(System.currentTimeMillis() + expiration * 1000);
	}

	/**
	 * 判断token是否在有效期内
	 * 
	 * @param token
	 * @return 在有效期内返回false，不在有效期内返回true
	 */
	public Boolean isTokenExpired(String token) {
		final Date expiration = getExpirationDateFromToken(token);
		// date1.before(date2)当Date1小于Date2时，返回TRUE
		return expiration.before(new Date());
	}

	/**
	 * 判断创建是否在修改密码之前
	 * 
	 * @param created
	 * @param lastPasswordReset
	 * @return 在则返回false 不在则返回true
	 */
	public Boolean isCreatedBeforeLastPasswordReset(Date created,
			Date lastPasswordReset) {
		return (lastPasswordReset != null && created.before(lastPasswordReset));
	}

	/**
	 * 生成jwt
	 */
	public String generateToken(String username,String client_id) {
		Map<String, Object> claims = new HashMap<>();
		claims.put(CLAIM_KEY_USERNAME, username);
		claims.put(CLAIM_KEY_CLIENTID, client_id);
		claims.put(CLAIM_KEY_CREATED, new Date());
		return createToken(claims);
	}

	/**
	 * 生成jwt
	 */
	String createToken(Map<String, Object> claims) {
		return Jwts.builder().setClaims(claims)
				.setExpiration(generateExpirationDate())
				.signWith(SignatureAlgorithm.HS256, secret).compact();
	}

	/**
	 * 生成刷新token
	 * 
	 * @param lihao
	 * @return
	 */
	public String getRefreshToken(String username,String client_id) {
		Map<String, Object> claims = new HashMap<>();
		claims.put(CLAIM_KEY_USERNAME, username);
		claims.put(CLAIM_KEY_CLIENTID, client_id);
		claims.put(CLAIM_KEY_CREATED, new Date(System.currentTimeMillis()
				+ refresh_time * 1000));
		return createToken(claims);
	}

	/**
	 * 判断token是否可以刷新
	 * 
	 * @param token
	 * @param lastPasswordReset
	 * @return
	 */
	public Boolean canTokenBeRefreshed(String token, Date lastPasswordReset) {
		final Date create = getCreatedDateFromToken(token);
		return !isCreatedBeforeLastPasswordReset(create, lastPasswordReset)
				&& !isTokenExpired(token);
	}

	/**
	 * 更新token
	 * 
	 * @param token
	 * @return
	 */
	public String refreshToken(String token) {
		String refreshedToken;
		try {
			final Claims claims = getClaimsFromToken(token);
			claims.put(CLAIM_KEY_CREATED, new Date());
			refreshedToken = createToken(claims);
		} catch (Exception e) {
			refreshedToken = null;
		}
		return refreshedToken;
	}

	/**
	 * 验证令牌
	 * 
	 * @param token
	 * @return
	 */
	public Boolean validateToken(String token, LiHao lihao) {
		final String username = getUsernameFromToken(token);
		final Date created = getCreatedDateFromToken(token);

		return (username.equals(lihao.getUsername()) && !isTokenExpired(token) && !isCreatedBeforeLastPasswordReset(
				created, lihao.getLastPasswordResetDate()));
	}

}
