package com.lihao.app.controller;

import io.swagger.annotations.ApiOperation;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * 用于网站映射
 * @author lihao.fnst
 *
 */
@Controller
public class WebController {
	
	private static final Logger logger = LoggerFactory.getLogger(WebController.class);
	
	@ApiOperation(value = "index界面" , httpMethod = "POST" , notes="测试")
	@RequestMapping(value="/index" , method = RequestMethod.GET)
	public ModelAndView getindex() {
		logger.info("\n in index:");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("index");
		mav.addObject("say", "welcome");
		return mav;
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView getregister() {
		logger.info("\n in register:");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("register");
		return mav;
	}
	
	@RequestMapping(value = "/error", method = RequestMethod.GET)
	public ModelAndView geterror() {
		logger.info("\n in error:");
		ModelAndView mav = new ModelAndView();
		mav.setViewName("error");
		return mav;
	}
	
}
