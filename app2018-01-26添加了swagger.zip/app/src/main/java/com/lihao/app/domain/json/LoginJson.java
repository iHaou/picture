package com.lihao.app.domain.json;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 用户登陆输入json格式
 * @author lihao.fnst
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginJson {
	private String username;
	private String password;
}
