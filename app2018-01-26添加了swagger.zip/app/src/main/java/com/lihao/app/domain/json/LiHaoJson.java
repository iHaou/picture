package com.lihao.app.domain.json;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 注册所需json格式
 * @author lihao.fnst
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LiHaoJson {
	private String username;
	private String password;
	private String name;
	private Integer age;
	private Date lastPasswordResetDate;
}
