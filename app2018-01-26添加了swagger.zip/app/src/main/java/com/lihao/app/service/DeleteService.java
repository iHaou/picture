package com.lihao.app.service;

public interface DeleteService {

//	刪除应用
	int delSoft(int id);

//	删除用户
	int delUser(int id);
	
}
