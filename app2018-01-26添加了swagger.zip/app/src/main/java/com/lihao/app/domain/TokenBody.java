package com.lihao.app.domain;

import java.util.Date;

import lombok.Data;

/**
 * token的返回 access_token 授权token refresh_token 刷新token expiration 有效时间
 * token_type token类型
 * 
 * @author lihao.fnst
 *
 */

public class TokenBody {
	private String access_token;
	private String refresh_token;
	private Long expiration;
	private String tokentype;
	private String scope;

	public TokenBody(){
		this.expiration = 604800L;
		this.tokentype = "example";
		this.scope = "basic";
	}
	
	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public String getRefresh_token() {
		return refresh_token;
	}

	public void setRefresh_token(String refresh_token) {
		this.refresh_token = refresh_token;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public Long getExpiration() {
		return expiration;
	}

	public String getTokentype() {
		return tokentype;
	}

	@Override
	public String toString() {
		return "TokenBody [access_token=" + access_token + ",\nrefresh_token="
				+ refresh_token + ",\nscope=" + scope + ",\nexpiration="
				+ expiration + ",\ntokentype=" + tokentype + "]";
	}

}
