package com.lihao.app.domain.json;

import lombok.Data;

@Data
public class RequestJson {
	private String client_id;
	private String client_secret;
	private String redirect_url;
}
