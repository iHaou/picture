package com.lihao.app.entity;

import java.io.Serializable;

import lombok.Data;

/**
 * tb_soft实体类
 * @author lihao.fnst
 *
 */
@Data
public class LiHaoSoft implements Serializable{
	private Integer id;
	private String client_id;
	private String client_secret;
	private String client_name;
	private String redirect_url;
	private String userid;
}
