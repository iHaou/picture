package com.lihao.app.dao;

import org.springframework.stereotype.Repository;

import com.lihao.app.domain.json.LiHaoJson;
import com.lihao.app.domain.json.LoginJson;
import com.lihao.app.entity.LiHao;
/**
 * 针对用户操作
 * @author lihao.fnst
 *
 */
@Repository
public interface AuthUserMapper {
//	用户注册
	int insert(LiHaoJson lihao);
//	用户删除
	int Delete(int id);
//	查找用户是否存在
	LiHao selectUser(LoginJson loginJson);
//	根据用户id来查找信息。
	LiHao selectId(Integer userid);
}
