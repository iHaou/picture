package com.lihao.app.domain.json;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 用于传输注册应用的数据
 * @author lihao.fnst
 *
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SoftJson {
	private String client_id;
	private String client_secret;
	private String client_name;
	private String redirect_url;
	private Integer userid;
}
