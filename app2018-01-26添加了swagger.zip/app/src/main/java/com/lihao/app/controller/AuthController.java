package com.lihao.app.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.lihao.app.domain.TokenBody;
import com.lihao.app.domain.enums.ResultEnum;
import com.lihao.app.domain.json.LoginJson;
import com.lihao.app.domain.json.LiHaoJson;
import com.lihao.app.domain.json.ResultBody;
import com.lihao.app.domain.json.SoftJson;
import com.lihao.app.service.AuthService;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiOperation;

/**
 * 只需要开始的简单的输入账号密码验证 注册应用
 * 
 * @author lihao.fnst
 *
 */
@Controller
@Api(value = "auth")
public class AuthController {

	// 日志打印
	private static final Logger logger = LoggerFactory
			.getLogger(AuthController.class);

	@Autowired
	private AuthService authservice;

	/**
	 * 用户注册 未完成
	 * 
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "注册用户",response = ResponseEntity.class,httpMethod="POST",notes="用户注册")
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> Postregister(LiHaoJson lihao) throws Exception {
		logger.info("\n insert user1 " + lihao.toString());
		int flag = authservice.Regiseter(lihao);
		if (flag != 0) {
			return ResponseEntity.ok(new ResultBody(ResultEnum.SUCCESS, lihao));
		} else {
			return ResponseEntity.ok(new ResultBody(ResultEnum.FALUE, lihao));
		}
	}

	/**
	 * 用户注册应用程序 未完成： 没有重复判断 应用程序的key,secret的生成（自动生成不重复） 应用程序的用户名应该自动后台获取，不该由用户输入
	 * 
	 * @return
	 */
	@RequestMapping(value = "/soft", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> PostSoft(SoftJson softJson) {
		logger.info("\n insert soft " + softJson.toString());
		int flag = authservice.AddSoft(softJson);
		if (flag != 0) {
			return ResponseEntity.ok(new ResultBody(ResultEnum.SUCCESS,
					softJson));
		} else {
			return ResponseEntity
					.ok(new ResultBody(ResultEnum.FALUE, softJson));
		}
	}

	/**
	 * 接收用户从第三方引导过来的授权处理页面
	 * 
	 * @return
	 */
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView GetPower(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/**
		 * 用户验证，成功后加载login界面
		 */
		Boolean flag = false;
		ModelAndView mav = new ModelAndView();

		flag = authservice.GetPower(request, response);
		if (flag) {
			mav.setViewName("login");
			return mav;
		} else {
			mav.setViewName("error");
			return mav;
		}
	}

	/**
	 * 登陆界面用户验证
	 * 
	 * @throws Exception
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	@ResponseBody
	public void GetAppid(HttpServletRequest request,
			HttpServletResponse response, LoginJson loginJson) throws Exception {

		logger.info("\nlogin post:" + request.getParameter("client_id"));
		authservice.GetUserTrue(loginJson, request, response);
	}

	/**
	 * 进入授权页面询问客户是否授权
	 * 
	 * @return
	 */
	@RequestMapping(value = "/authorize", method = RequestMethod.GET)
	public ModelAndView getauthorize(HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("\n in authorize:" + request.getQueryString());
		ModelAndView mav = new ModelAndView();
		return authservice.authorization(request, response, mav);
	}

	/**
	 * 生成授权码
	 * 
	 * @param response
	 * @param request
	 */
	@RequestMapping(value = "/authorize", method = RequestMethod.POST)
	public void PostAuthorize(HttpServletResponse response,
			HttpServletRequest request) {
		logger.info("\n in PostAuthorize " + request.getQueryString());
		authservice.CreateCode(request, response);
	}

	/**
	 * 客户端通过code来获取accesstoken
	 * 
	 * @param request
	 * @param response
	 */
	@RequestMapping(value = "/getToken", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<?> getAccess_Token(HttpServletRequest request,
			HttpServletResponse response) {
		logger.info("\n 用code换取token" + request.getParameter("code"));
		TokenBody token = authservice.GetAccessToken(request, response);
		if (token != null) {
			return ResponseEntity.ok(new ResultBody(ResultEnum.SUCCESS, token));
		}
		return ResponseEntity.ok(new ResultBody(ResultEnum.FALUE, token));
	}
	/**
	 * 通过refreshtoken来刷新token
	 * 需要client_id和refreshtoken
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/refreshToken",method = RequestMethod.GET)
	public ResponseEntity<?> refresh_Token(HttpServletRequest request,HttpServletResponse response){
		return authservice.refresh_Token(request,response);
	}
}
