package com.lihao.app.service.imp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lihao.app.dao.AuthSoftMapper;
import com.lihao.app.dao.AuthUserMapper;
import com.lihao.app.service.DeleteService;

@Service
public class DeleteServiceImp implements DeleteService {

	private static final Logger logger = LoggerFactory.getLogger(DeleteServiceImp.class);
	
	@Autowired
	private AuthSoftMapper softMapper;
	@Autowired
	private AuthUserMapper userMapper;
	
	public int delSoft(int id) {
		// TODO Auto-generated method stub
		int flag = softMapper.Delete(id);
		return flag;
	}

	public int delUser(int id) {
		// TODO Auto-generated method stub
		int flag = userMapper.Delete(id);
		return flag;
	}

}
