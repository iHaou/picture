package com.lihao.app.entity;

import java.io.Serializable;

import lombok.Data;

/**
 * tb_authorize实体类
 * @author lihao.fnst
 *
 */
@Data
public class LiHaoCode implements Serializable{
	private Integer id;
	private Integer userid;
	private String client_id;
	private String code;
}
