package com.swagger.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.swagger.domain.ResultBody;
import com.swagger.domain.ResultEnum;
import com.swagger.domain.Test_User;
import com.wordnik.swagger.annotations.Api;
import com.wordnik.swagger.annotations.ApiImplicitParam;
import com.wordnik.swagger.annotations.ApiImplicitParams;
import com.wordnik.swagger.annotations.ApiOperation;
import com.wordnik.swagger.annotations.ApiParam;
import com.wordnik.swagger.annotations.ApiResponse;
import com.wordnik.swagger.annotations.ApiResponses;

@Api(value="controller")
@Controller
public class HelloworldController {

	@ApiOperation(value = "hello",httpMethod="GET",notes="测试")
	@RequestMapping(value="/hello",method=RequestMethod.GET)
	public ModelAndView getHello(HttpServletResponse response,
			HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("hello");
		return mav;
	}
	
	@RequestMapping(value="/index",method=RequestMethod.GET)
	public ModelAndView getindex(){
		ModelAndView mav = new ModelAndView();
		mav.setViewName("index");
		return mav;
	}

	@ApiOperation(value="test",httpMethod="post",notes="输入user类,在正式运行用form表单或者url方式传输数据要将@requestbody删除，否则报错")
	@RequestMapping(value = "/test", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<?> getTest(@RequestBody Test_User user) throws Exception {
		return ResponseEntity.ok(new ResultBody(ResultEnum.SUCCESS, user));

	}
}
