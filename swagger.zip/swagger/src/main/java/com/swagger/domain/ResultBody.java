package com.swagger.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 返回值格式
 * @author lihao.fnst
 *
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@ApiModel
public class ResultBody {
	@ApiModelProperty(value="状态码",example="001")
	private String code;
	@ApiModelProperty(value="状态码描述",example="操作成功")
	private String describe;
	@ApiModelProperty(value="数据",example="")
	private Object content;
	public ResultBody(ResultEnum resultEnum,Object object){
		this.code = resultEnum.getCode();
		this.describe = resultEnum.getDescribe();
		this.content = object;
	}
}
