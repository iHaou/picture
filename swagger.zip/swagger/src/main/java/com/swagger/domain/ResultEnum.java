package com.swagger.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * 返回提示信息
 * @author lihao.fnst
 *
 */
@Getter
@AllArgsConstructor
public enum ResultEnum {
	SUCCESS("001","操作成功"),
	FALUE("101","操作失败"),
	WAIT_TODO("110","功能尚未完成");
	private String code,describe;
}
