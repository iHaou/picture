package com.swagger.services;

import java.io.File;
import java.util.Locale;

import org.springframework.web.servlet.view.InternalResourceView;

/**
 * 用于判断网页为jsp还是html
 * @author lihao.fnst
 *
 */
public class HtmlResourceView extends InternalResourceView {
	@Override
	public boolean checkResource(Locale locale){
		File file = new File(this.getServletContext().getRealPath("/")+getUrl());
		return file.exists();
	}
}
