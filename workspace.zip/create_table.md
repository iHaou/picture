# postgreSQL

        jdbc.url=jdbc:postgresql://193.160.33.37:5432/testdb
        jdbc.username=postgres
        jdbc.password=fnst1234

## 创建用户表

    CREATE TABLE IF NOT EXISTS tb_user(
        id serial primary key,
        username VARCHAR(50),
        password VARCHAR(50),
        name VARCHAR(30),
        age smallint
        );

## 创建软件表

        CREATE TABLE IF NOT EXISTS tb_soft(
        id serial primary key,
        client_id VARCHAR(40),
        client_secret VARCHAR(50),
        client_name VARCHAR(30),
        redirect_url VARCHAR(80),
        userid integer,
        FOREIGN KEY (userid) REFERENCES tb_user(id),
        CONSTRAINT uk_tb_soft_client_id UNIQUE (client_id)
        );

        CREATE TABLE IF NOT EXISTS tb_soft(
        id serial primary key,
        client_id VARCHAR(40),
        client_secret VARCHAR(50),
        client_name VARCHAR(30),
        redirect_url VARCHAR(80),
        userid integer,
        CONSTRAINT uk_tb_soft_client_id UNIQUE (client_id)
        );

## 创建授权表

        CREATE TABLE IF NOT EXISTS tb_authorize(
        id serial primary key,
        userid integer,
        client_id VARCHAR(40),
        code VARCHAR(40),
        FOREIGN KEY (client_id) REFERENCES tb_soft(client_id),
        FOREIGN KEY (userid) REFERENCES tb_user(id)
        );

        CREATE TABLE IF NOT EXISTS tb_authorize(
        id serial primary key,
        userid integer,
        client_id VARCHAR(40),
        code VARCHAR(40)
        );

## 删除表

        DROP TABLE tb_soft;
        DROP TABLE tb_user;
        DROP TABLE tb_authorize;
        DROP TABLE tb_soft,tb_user,tb_authorize;

## 改变表结构

        ### 添加新列

        ALTER TABLE table_name ADD column_name datatype;

        ### 删除列

        ALTER TABLE table_name DROP column_name datatype;

        ### 更改列属性

        ALTER TABLE table_name ALTER COLUMN column_name TYPE datatype;

        ### 添加列的唯一性

        ALTER TABLE table_name ADD CONSTRAINT uk_table_name_column_name unique(column_name);

[易佰教程][易佰教程]

[易佰教程]:http://www.yiibai.com/postgresql/postgresql_alter_command.html
