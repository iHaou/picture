# postgreSQL

    jdbc.url=jdbc:postgresql://193.160.33.37:5432/testdb
    jdbc.username=postgres
    jdbc.password=fnst1234

## 查找命令

    SELECT * FROM tb_user;
    SELECT * FROM tb_soft;

## 插入命令

### 插入用户user

    INSERT INTO tb_user(username,password,name,age)
    VALUES(${username},${password},${name},${age});

#### 数据库中例子

    INSERT INTO tb_user(username,password,name,age)
    VALUES('lihao','lihao','lihao',20);

### 插入应用

    INSERT INTO tb_soft(appkey,client_secret,appname,return_url,userid)
    VALUES('appkey','client_secret','appname','return_url',1);

## 删除行

    DELETE FROM tb_soft
    where id = 1;

## 查找用户是否存在

    SELECT * FROM tb_user
    WHERE username = 'lihao' AND password = 'lihao';

[mybatis标签使用][csdn标签]

[csdn标签]:http://blog.csdn.net/qq_29233973/article/details/51433924